/* StyleIQ — Galaxy Space Background */
(function () {
  const canvas = document.getElementById('particles');
  if (!canvas) return;
  const ctx = canvas.getContext('2d');
  let W, H, stars = [], nebulas = [], shootingStars = [];

  function resize() { W = canvas.width = window.innerWidth; H = canvas.height = window.innerHeight; }

  // Stars
  function Star() {
    this.x = Math.random() * W;
    this.y = Math.random() * H;
    this.size = Math.random() * 1.8 + 0.2;
    this.baseOpacity = Math.random() * 0.8 + 0.1;
    this.opacity = this.baseOpacity;
    this.twinkleSpeed = Math.random() * 0.02 + 0.005;
    this.twinkleDir = Math.random() > 0.5 ? 1 : -1;
    const r = Math.random();
    this.color = r > 0.7 ? '#00d4ff' : r > 0.45 ? '#b400ff' : r > 0.25 ? '#ff00c8' : '#ffffff';
  }
  Star.prototype.update = function () {
    this.opacity += this.twinkleSpeed * this.twinkleDir;
    if (this.opacity > this.baseOpacity + 0.3 || this.opacity < 0.05) this.twinkleDir *= -1;
  };
  Star.prototype.draw = function () {
    ctx.beginPath();
    ctx.arc(this.x, this.y, this.size, 0, Math.PI * 2);
    ctx.fillStyle = this.color;
    ctx.globalAlpha = Math.max(0, this.opacity);
    if (this.size > 1.2) {
      ctx.shadowBlur = 8;
      ctx.shadowColor = this.color;
    }
    ctx.fill();
    ctx.shadowBlur = 0;
  };

  // Nebula clouds
  function Nebula() {
    this.x = Math.random() * W;
    this.y = Math.random() * H;
    this.r = Math.random() * 200 + 80;
    this.color = Math.random() > 0.5 ? 'rgba(0,212,255,' : 'rgba(180,0,255,';
    this.opacity = Math.random() * 0.04 + 0.01;
    this.drift = (Math.random() - 0.5) * 0.1;
  }
  Nebula.prototype.draw = function () {
    const grad = ctx.createRadialGradient(this.x, this.y, 0, this.x, this.y, this.r);
    grad.addColorStop(0, this.color + this.opacity + ')');
    grad.addColorStop(1, this.color + '0)');
    ctx.beginPath();
    ctx.arc(this.x, this.y, this.r, 0, Math.PI * 2);
    ctx.fillStyle = grad;
    ctx.globalAlpha = 1;
    ctx.fill();
    this.x += this.drift;
    if (this.x < -this.r) this.x = W + this.r;
    if (this.x > W + this.r) this.x = -this.r;
  };

  // Shooting stars
  function ShootingStar() {
    this.reset();
  }
  ShootingStar.prototype.reset = function () {
    this.x = Math.random() * W;
    this.y = Math.random() * H * 0.5;
    this.len = Math.random() * 120 + 40;
    this.speed = Math.random() * 8 + 4;
    this.angle = Math.PI / 4 + (Math.random() - 0.5) * 0.4;
    this.opacity = 1;
    this.active = false;
    this.timer = Math.random() * 300 + 100;
  };
  ShootingStar.prototype.update = function () {
    if (!this.active) { this.timer--; if (this.timer <= 0) this.active = true; return; }
    this.x += Math.cos(this.angle) * this.speed;
    this.y += Math.sin(this.angle) * this.speed;
    this.opacity -= 0.02;
    if (this.opacity <= 0 || this.x > W || this.y > H) this.reset();
  };
  ShootingStar.prototype.draw = function () {
    if (!this.active) return;
    const tailX = this.x - Math.cos(this.angle) * this.len;
    const tailY = this.y - Math.sin(this.angle) * this.len;
    const grad = ctx.createLinearGradient(tailX, tailY, this.x, this.y);
    grad.addColorStop(0, 'rgba(0,212,255,0)');
    grad.addColorStop(1, `rgba(0,212,255,${this.opacity})`);
    ctx.beginPath();
    ctx.moveTo(tailX, tailY);
    ctx.lineTo(this.x, this.y);
    ctx.strokeStyle = grad;
    ctx.globalAlpha = this.opacity;
    ctx.lineWidth = 1.5;
    ctx.stroke();
    // Head glow
    ctx.beginPath();
    ctx.arc(this.x, this.y, 2, 0, Math.PI * 2);
    ctx.fillStyle = '#ffffff';
    ctx.globalAlpha = this.opacity;
    ctx.fill();
  };

  function init() {
    resize();
    stars = Array.from({ length: 200 }, () => new Star());
    nebulas = Array.from({ length: 6 }, () => new Nebula());
    shootingStars = Array.from({ length: 4 }, () => new ShootingStar());
  }

  function animate() {
    ctx.clearRect(0, 0, W, H);
    // Deep space background gradient
    const bgGrad = ctx.createRadialGradient(W/2, H/2, 0, W/2, H/2, Math.max(W, H));
    bgGrad.addColorStop(0, 'rgba(5,0,20,.4)');
    bgGrad.addColorStop(0.5, 'rgba(2,0,15,.3)');
    bgGrad.addColorStop(1, 'rgba(0,0,8,.5)');
    ctx.fillStyle = bgGrad;
    ctx.globalAlpha = 1;
    ctx.fillRect(0, 0, W, H);

    // Nebulas
    nebulas.forEach(n => n.draw());
    // Stars
    stars.forEach(s => { s.update(); s.draw(); });
    // Shooting stars
    shootingStars.forEach(s => { s.update(); s.draw(); });

    ctx.globalAlpha = 1;
    requestAnimationFrame(animate);
  }

  window.addEventListener('resize', () => { resize(); });
  init();
  animate();
})();
